# q-learning
#Q learning exercises from our Computer Learning class. The goal is to help a robot navigate a maze.
